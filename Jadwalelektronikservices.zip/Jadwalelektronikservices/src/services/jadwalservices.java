/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package services;

import java.util.ArrayList;
import java.util.List;
import model.jadwal;
/**
 *
 * @author Vivobook
 */
public class jadwalservices {
private List<jadwal> daftarJadwal = new ArrayList<>();

    public void tambahJadwal(jadwal j) {
        daftarJadwal.add(j);
    }

    public List<jadwal> getAllJadwal() {
        return daftarJadwal;
    }

    public boolean hapusJadwal(int id) {
        return daftarJadwal.removeIf(j -> j.getId() == id);
    }

    public boolean updateJadwal(int id, String namaBaru, String tanggalBaru) {
        for (jadwal j : daftarJadwal) {
            if (j.getId() == id) {
                j.setNamaService(namaBaru);
                j.setTanggal(tanggalBaru);
                return true;
            }
        }
        return false;
    }

    public jadwal searchJadwal(int id) {
        for (jadwal j : daftarJadwal) {
            if (j.getId() == id) return j;
        }
        return null;
    }
}