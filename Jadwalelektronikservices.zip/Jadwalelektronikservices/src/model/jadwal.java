/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Vivobook
 */
public class jadwal {
    private int id;
    private String namaService;
    private String tanggal;

    public jadwal(int id, String namaService, String tanggal) {
        this.id = id;
        this.namaService = namaService;
        this.tanggal = tanggal;
    }

    public int getId() { return id; }
    public String getNamaService() { return namaService; }
    public void setNamaService(String namaService) { this.namaService = namaService; }
    public String getTanggal() { return tanggal; }
    public void setTanggal(String tanggal) { this.tanggal = tanggal; }

    @Override
    public String toString() {
        return "ID: " + id + " | Nama Service: " + namaService + " | Tanggal: " + tanggal;
    }
}
