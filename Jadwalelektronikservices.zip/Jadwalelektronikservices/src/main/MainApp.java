/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import java.util.Scanner;
import model.jadwal;
import services.jadwalservices;
/**
 *
 * @author Vivobook
 */
public class MainApp {
public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        jadwalservices service = new jadwalservices();

        while (true) {
            System.out.println("\n=== MENU JADWAL SERVICE ELEKTRONIK ===");
            System.out.println("1. Tambah Jadwal");
            System.out.println("2. Lihat Jadwal");
            System.out.println("3. Hapus Jadwal");
            System.out.println("4. Update Jadwal");
            System.out.println("5. Cari Jadwal");
            System.out.println("0. Keluar");
            System.out.print("Pilih: ");

            if (!scanner.hasNextInt()) {
                System.out.println("Input harus angka!");
                scanner.nextLine();
                continue;
            }
            int pilihan = scanner.nextInt();
            scanner.nextLine();

            switch (pilihan) {
                case 1:
                    System.out.print("Masukkan ID: ");
                    int id = scanner.nextInt(); scanner.nextLine();
                    System.out.print("Masukkan Nama Service: ");
                    String nama = scanner.nextLine();
                    System.out.print("Masukkan Tanggal: ");
                    String tanggal = scanner.nextLine();
                    service.tambahJadwal(new jadwal(id, nama, tanggal));
                    System.out.println("✅ Jadwal berhasil ditambahkan!");
                    break;

                case 2:
                    System.out.println("\n--- Daftar Jadwal ---");
                    if (service.getAllJadwal().isEmpty()) {
                        System.out.println("Belum ada jadwal!");
                    } else {
                        for (jadwal j : service.getAllJadwal()) System.out.println(j);
                    }
                    break;

                case 3:
                    System.out.print("Masukkan ID yang ingin dihapus: ");
                    int hapusId = scanner.nextInt();
                    if (service.hapusJadwal(hapusId)) {
                        System.out.println("✅ Jadwal berhasil dihapus!");
                    } else {
                        System.out.println("❌ Jadwal tidak ditemukan!");
                    }
                    break;

                case 4:
                    System.out.print("Masukkan ID yang ingin diupdate: ");
                    int updateId = scanner.nextInt(); scanner.nextLine();
                    System.out.print("Masukkan Nama Service baru: ");
                    String newNama = scanner.nextLine();
                    System.out.print("Masukkan Tanggal baru: ");
                    String newTanggal = scanner.nextLine();
                    if (service.updateJadwal(updateId, newNama, newTanggal)) {
                        System.out.println("✅ Jadwal berhasil diupdate!");
                    } else {
                        System.out.println("❌ Jadwal tidak ditemukan!");
                    }
                    break;

                case 5:
                    System.out.print("Masukkan ID yang ingin dicari: ");
                    int searchId = scanner.nextInt();
                    jadwal hasil = service.searchJadwal(searchId);
                    if (hasil != null) System.out.println("✅ Jadwal ditemukan: " + hasil);
                    else System.out.println("❌ Jadwal tidak ditemukan!");
                    break;

                case 0:
                    System.out.println("Keluar dari program...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Pilihan tidak valid!");
            }
        }
    }
}
